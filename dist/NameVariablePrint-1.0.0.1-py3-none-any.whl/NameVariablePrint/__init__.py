__version__ = '1.0.0.1'
__all__=['nvprint']